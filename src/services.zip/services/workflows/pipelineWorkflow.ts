import { uploadFile } from '../openai/files'
import { createPdfFromText } from '../openai/pdf'
import { createResponse, extractOutputText } from '../openai/responses'

export type PipelineMode = 'start' | 'rerun' | 'continue'

export type PipelineStageKey = 'requirements' | 'tests' | 'queries'

export type PipelineStage = {
  key: PipelineStageKey
  label: string
  prompt: string
}

export type PipelineStageResult = PipelineStage & {
  outputText: string
  raw: unknown
}

export type PipelinePreviousOutputs = Partial<Record<PipelineStageKey, string>>

export type PipelineInput = {
  files: File[]
  mode?: PipelineMode
  model?: string
  previous?: PipelinePreviousOutputs
  signal?: AbortSignal
  onStageChange?: (stage: PipelineStage) => void
}

export type PipelineResult = {
  stages: PipelineStageResult[]
  pdf: {
    blob: Blob
    fileId: string
  }
}

export const PIPELINE_STAGES: PipelineStage[] = [
  {
    key: 'requirements',
    label: 'Requirements -> atomic behaviors',
    prompt:
      'Prompt 1 - Artifact Normalizer (Requirements -> atomic behaviors)\nNormalize requirement artifacts into atomic, testable behaviors.\nOutput a numbered list. If ambiguous, note the assumption.',
  },
  {
    key: 'tests',
    label: 'Tests -> inventory + assertions',
    prompt:
      'Prompt 2 - Artifact Normalizer (Tests -> test inventory + assertion extraction)\nExtract a test inventory and the assertions for each test. Output concise bullet lists.',
  },
  {
    key: 'queries',
    label: 'Requirement -> retrieval queries',
    prompt:
      'Prompt 3 - Retriever Query Builder (Requirement -> retrieval queries)\nGenerate concise retrieval queries that would find relevant context. Output 8-15 queries.',
  },
]

const buildStagePrompt = (
  base: string,
  mode: PipelineMode,
  previousOutput?: string
) => {
  if (mode !== 'continue' || !previousOutput?.trim()) {
    return base
  }
  return `${base}\n\nPrevious output:\n${previousOutput}\n\nContinue from the previous output. Extend and refine it.`
}

const buildPdfPrompt = (stages: PipelineStageResult[]) => {
  const sections = stages
    .map(
      (stage) =>
        `### ${stage.label}\n${stage.outputText || 'No output generated.'}`
    )
    .join('\n\n')
  return `Create a clean PDF report with the following sections. Preserve headings and bullet lists.\n\n${sections}`
}

export const runArtifactPipeline = async ({
  files,
  mode = 'start',
  model,
  previous,
  signal,
  onStageChange,
}: PipelineInput): Promise<PipelineResult> => {
  if (!files.length) {
    throw new Error('No files provided for upload.')
  }

  const uploaded = await Promise.all(files.map((file) => uploadFile(file, signal)))
  const fileInputs = uploaded.map((file) => ({ type: 'input_file', file_id: file.id }))

  const results: PipelineStageResult[] = []

  for (const stage of PIPELINE_STAGES) {
    onStageChange?.(stage)
    const prompt = buildStagePrompt(stage.prompt, mode, previous?.[stage.key])
    const response = await createResponse({
      model,
      input: [
        {
          role: 'user',
          content: [{ type: 'input_text', text: prompt }, ...fileInputs],
        },
      ],
      signal,
    })
    const outputText = extractOutputText(response)
    results.push({
      ...stage,
      prompt,
      outputText,
      raw: response,
    })
  }

  const pdfPrompt = buildPdfPrompt(results)
  const pdf = await createPdfFromText({
    text: pdfPrompt,
    model,
    signal,
  })

  return {
    stages: results,
    pdf: {
      blob: pdf.blob,
      fileId: pdf.fileId,
    },
  }
}
